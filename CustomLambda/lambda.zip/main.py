import boto3
import csv
import time

csv_file_path = 'data - Sheet1.csv'

access_key = 'AKIA3DYF5NXR2GJ26I55'
secret_key = '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'

session = boto3.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_key)
s3_client = session.client('s3')

with open(csv_file_path, 'r') as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader)
    data = []
    for row in csv_reader:
        data.append(row)


for row in data:
    print("deleting bucket: ", row[0])
    bucket_name = row[0]
    s3_client.delete_bucket(Bucket=bucket_name)
    time.sleep(1)
    print("bucket deleted: ", row[0])





# for row in data:
#     print("creating bucket: ", row[0])
#     bucket_name = row[0]
#     s3_client.create_bucket(Bucket=bucket_name)
#     time.sleep(1)
#     print("bucket created: ", row[0])
